//
// Functionality to simulate Plug and Play.
// This is loosly based on the Plug and Play functionality under MacOS,
// but has been changed for ease-of-use since the main goal is to
// ensure that the device management is working properly.

#ifndef PLUG_AND_PLAY_HPP
#define PLUG_AND_PLAY_HPP

constexpr size_t strLength = 30U;
constexpr uint32_t PreSonusVendorId = 1;

// Known product IDs.  All other product IDs are considered USB devices.
enum class ProductIds : std::uint16_t
{
    FaderPort = 0,
    AtomPad = 1,
    Quantum = 2
};

struct PlugAndPlayInfo
{
    char deviceName[strLength];
    std::uint32_t hardwareId = 0U;
    std::uint16_t vendorId = 0U;
    std::uint16_t productId = 0U;
    char firmwareVersion[strLength];
    std::uint32_t serialNumber = 0U;
    std::uint16_t numberOfInputs = 0U;
    std::uint16_t numberOfOutputs = 0U;
};

#endif
