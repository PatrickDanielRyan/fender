//
// Quantum Device
//

#ifndef QUANTUM_DEVICE_HPP
#define QUANTUM_DEVICE_HPP

#include "PreSonusDevice.hpp"

namespace PreSonus
{
class QuantumDevice : public PreSonusDevice
{
public:
    QuantumDevice() = default;
    QuantumDevice(const QuantumDevice&) = delete;
    QuantumDevice(QuantumDevice&&) = delete;
    QuantumDevice operator=(const QuantumDevice&) = delete;
    QuantumDevice operator=(QuantumDevice&&) = delete;

    bool controlDevice(std::uint32_t instructionId) noexcept override final;
};

} // Namespace

#endif
