//
// Studio USB Device
//

#ifndef STUDIOUSB_DEVICE_HPP
#define STUDIOUSB_DEVICE_HPP

#include "PreSonusDevice.hpp"

namespace PreSonus
{
class StudioUsbDevice : public PreSonusDevice
{
public:
    StudioUsbDevice() = default;
    StudioUsbDevice(const StudioUsbDevice&) = delete;
    StudioUsbDevice(StudioUsbDevice&&) = delete;
    StudioUsbDevice operator=(const StudioUsbDevice&) = delete;
    StudioUsbDevice operator=(StudioUsbDevice&&) = delete;

    bool controlDevice(std::uint32_t instructionId) noexcept override final;
};

} // Namespace

#endif
