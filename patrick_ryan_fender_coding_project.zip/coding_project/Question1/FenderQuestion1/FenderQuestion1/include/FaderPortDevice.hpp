//
// Fader Port Device
//

#ifndef FADERPORT_DEVICE_HPP
#define FADERPORT_DEVICE_HPP

#include "PreSonusDevice.hpp"

namespace PreSonus
{
class FaderPortDevice : public PreSonusDevice
{
public:
    FaderPortDevice() = default;
    FaderPortDevice(const FaderPortDevice&) = delete;
    FaderPortDevice(FaderPortDevice&&) = delete;
    FaderPortDevice operator=(const FaderPortDevice&) = delete;
    FaderPortDevice operator=(FaderPortDevice&&) = delete;

    bool controlDevice(std::uint32_t instructionId) noexcept override final;
};

} // Namespace

#endif
