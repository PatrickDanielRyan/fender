//
// Atom Pad Device
//

#ifndef ATOMPAD_DEVICE_HPP
#define ATOMPAD_DEVICE_HPP

#include "PreSonusDevice.hpp"

namespace PreSonus
{
class AtomPadDevice : public PreSonusDevice
{
public:
    AtomPadDevice() = default;
    AtomPadDevice(const AtomPadDevice&) = delete;
    AtomPadDevice(AtomPadDevice&&) = delete;
    AtomPadDevice operator=(const AtomPadDevice&) = delete;
    AtomPadDevice operator=(AtomPadDevice&&) = delete;

    bool controlDevice(std::uint32_t instructionId) noexcept override final;
};

} // Namespace

#endif
