//
// Abstract base class for PreSonus devices
//
// Contains the functionality common for all devices.
//

#ifndef PRESONUS_DEVICE_HPP
#define PRESONUS_DEVICE_HPP

#include <string>
#include <cstdint>

namespace PreSonus
{

class PreSonusDevice
{
public:
    PreSonusDevice() = default;
    PreSonusDevice(const PreSonusDevice&) = delete;
    PreSonusDevice(PreSonusDevice&&) = delete;
    PreSonusDevice operator=(const PreSonusDevice&) = delete;
    PreSonusDevice operator=(PreSonusDevice&&) = delete;
    virtual ~PreSonusDevice() {};
    
    // Getters common to all device types.
    std::string getDeviceName() const noexcept;
    std::uint32_t getHardwareId() const noexcept;
    std::uint16_t getVendorId() const noexcept;
    std::uint16_t getProductId() const noexcept;
    std::string getFirmwareVersion() const noexcept;
    std::uint32_t getSerialNumber() const noexcept;
    std::uint16_t getNumberOfInputs() const noexcept;
    std::uint16_t getNumberOfOutputs() const noexcept;
    
    // Setters common to all device types.
    void setDeviceName(const std::string &deviceName) noexcept;
    void setHardwareId(std::uint32_t hardwareId) noexcept;
    void setVendorId(std::uint16_t vendorId) noexcept;
    void setProductId(std::uint16_t productId) noexcept;
    void setFirmwareVersion(const std::string &firmwareVersion) noexcept;
    void setSerialNumber(std::uint32_t serialNumber) noexcept;
    void setNumberOfInputs(std::uint16_t numberOfInputs) noexcept;
    void setNumberOfOutputs(std::uint16_t numberOfOutputs) noexcept;
    
    // Functionality specific to each device type.
    virtual bool controlDevice(std::uint32_t instructionId) = 0; // Returns true if instruction was successful.
    
private:
    // Properties common to all devices.
    std::string m_deviceName;             // Human-readable device name.
    std::uint32_t m_hardwareId = 0U;      // Location of device (to be used for communciation with device).
    std::uint16_t m_vendorId = 0U;        // ID unique to vendor.
    std::uint16_t m_productId = 0U;       // ID unique to product.
    std::string m_firmwareVersion;        // Firmware version of device.
    std::uint32_t m_serialNumber = 0U;    // Product serial number.  Unique for products of a specific type from a specific vendor.
    std::uint16_t m_numberOfInputs = 0U;  // Number of inputs on the device.
    std::uint16_t m_numberOfOutputs = 0U; // Number of outputs on the device.
};

} // namespace PreSonus

#endif
