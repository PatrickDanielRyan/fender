//
// Manage the PreSonus Devices
//

#ifndef DEVICE_MANAGER_HPP
#define DEVICE_MANAGER_HPP

#include <tuple>
#include <map>
#include <memory>
#include <mutex>
#include <atomic>
#include <thread>

#include "PlugAndPlay.hpp"
#include "PreSonusDevice.hpp"

namespace PreSonus
{

// Map a serial number to a device.  Since we are only dealing with PreSonus devices, we
// can assume that all devices have a unique serial number.
// Use a map because the ordered keys will ensure the order of the print-out of the data
// structure remains sorted and consistent.
using SerialNumberToDevice = std::map<std::uint32_t, std::unique_ptr<PreSonusDevice>>;

class DeviceManager
{
public:
    DeviceManager();
    DeviceManager(const DeviceManager&) = delete;
    DeviceManager(DeviceManager&&) = delete;
    DeviceManager operator=(const DeviceManager&) = delete;
    DeviceManager operator=(DeviceManager&&) = delete;
    ~DeviceManager();
    
    // Return JSON formatted string containing the list of devices and all their properties.
    std::string getDeviceList();
    
    // Callbacks to be called when devices are added or removed.
    void onAddDevice(const std::vector<PlugAndPlayInfo>& plugAndPlayInfos) noexcept;
    void onRemoveDevice(const std::vector<PlugAndPlayInfo>& plugAndPlayInfos) noexcept;
    
private:
    void runNotificationLoop() noexcept; // Listens for adding and removing of devices.  To be run in separate thread.
    void getDevicesConnectedAtStartup(std::vector<PlugAndPlayInfo>& plugAndPlayInfos) noexcept; // Get devices already connected when program starts.
    
    void addDevice(const PlugAndPlayInfo& plugAndPlayInfo) noexcept; // Add PreSonus device to managed list of devices.
    void removeDevice(const PlugAndPlayInfo& plugAndPlayInfo) noexcept; // Remove PreSonus device from managed list of devices.
    
    void subscribeToAddEvents(std::function<void(const PlugAndPlayInfo& plugAndPlayInfo)>) noexcept;
    void subscribeToRemoveEvents(std::function<void(const PlugAndPlayInfo& plugAndPlayInfo)>) noexcept;
    
    std::atomic<bool> m_listenForEvents{true};   // True when listening for events should occur.
    std::mutex m_mutex;                          // Protects the map from serial number to device.
    std::thread m_listenThread;                  // Listens for add and remove events.
    SerialNumberToDevice m_serialNumberToDevice; // Maps Product Key to Device.
};

} // namespace

#endif
