//
// Manage the PreSonus Devices
//

#include <sstream>
#include <cstring>
#include <iostream>
#include <utility>
#include <thread>

#include "PlugAndPlay.hpp"
#include "FaderPortDevice.hpp"
#include "AtomPadDevice.hpp"
#include "StudioUsbDevice.hpp"
#include "QuantumDevice.hpp"

#include "DeviceManager.hpp"

namespace PreSonus
{

DeviceManager::DeviceManager()
{
    // Get devices connected at startup.
    std::vector<PlugAndPlayInfo> plugAndPlayInfos;
    getDevicesConnectedAtStartup(plugAndPlayInfos);
    
    for (const auto& plugAndPlayInfo : plugAndPlayInfos)
    {
        addDevice(plugAndPlayInfo);
    }
    
    // Start thread that listens for add and remove events.
    m_listenThread = std::thread(&DeviceManager::runNotificationLoop, this);
}

DeviceManager::~DeviceManager()
{
    m_listenForEvents = false;
    m_listenThread.join();
}

void DeviceManager::addDevice(const PlugAndPlayInfo& plugAndPlayInfo) noexcept
{
    using DevicePair = std::pair<std::uint32_t, std::unique_ptr<PreSonusDevice>>;
    
    // Only support PreSonus products.
    if (plugAndPlayInfo.vendorId != PreSonusVendorId)
    {
        std::cerr << "Only PreSonus devices are supported (detected device with VendorId=" << plugAndPlayInfo.vendorId << ")" << std::endl;
        return;
    }
    
    try
    {
        std::lock_guard<std::mutex> lock(m_mutex);
    
        bool result = false;
        switch (static_cast<ProductIds>(plugAndPlayInfo.productId))
        {
            case ProductIds::FaderPort:
                result = m_serialNumberToDevice.emplace(DevicePair{plugAndPlayInfo.serialNumber, std::make_unique<FaderPortDevice>()}).second;
                break;
            case ProductIds::AtomPad:
                result = m_serialNumberToDevice.emplace(DevicePair{plugAndPlayInfo.serialNumber, std::make_unique<AtomPadDevice>()}).second;
                break;
            case ProductIds::Quantum:
                result = m_serialNumberToDevice.emplace(DevicePair{plugAndPlayInfo.serialNumber, std::make_unique<QuantumDevice>()}).second;
                break;
            default:
                result = m_serialNumberToDevice.emplace(DevicePair{plugAndPlayInfo.serialNumber, std::make_unique<StudioUsbDevice>()}).second;
                break;
        }

        auto &device = m_serialNumberToDevice.at(plugAndPlayInfo.serialNumber);
    
        if (!result)
        {
            std::cerr << "Device with Serial Number " << device->getSerialNumber() << " already inserted" << std::endl;
            return;
        }
    
        device->setDeviceName(plugAndPlayInfo.deviceName);
        device->setHardwareId(plugAndPlayInfo.hardwareId);
        device->setVendorId(plugAndPlayInfo.vendorId);
        device->setProductId(plugAndPlayInfo.productId);
        device->setFirmwareVersion(plugAndPlayInfo.firmwareVersion);
        device->setSerialNumber(plugAndPlayInfo.serialNumber);
        device->setNumberOfInputs(plugAndPlayInfo.numberOfInputs);
        device->setNumberOfOutputs(plugAndPlayInfo.numberOfOutputs);
    }
    catch (const std::exception &e)
    {
        std::cerr << "Could not add device with serial number " << plugAndPlayInfo.serialNumber << " : " << e.what() << std::endl;
        return;
    }
}

void DeviceManager::removeDevice(const PlugAndPlayInfo& plugAndPlayInfo) noexcept
{
    try
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        auto result = m_serialNumberToDevice.erase(plugAndPlayInfo.serialNumber);
        if (!result)
        {
            std::cerr << "Erasure of device with Serial Number " << plugAndPlayInfo.serialNumber << " failed" << std::endl;
        }
    }
    catch (const std::exception &e)
    {
        std::cerr << "Could not remove device with serial number " << plugAndPlayInfo.serialNumber << " : " << e.what() << std::endl;
        return;
    }
}

void DeviceManager::onAddDevice(const std::vector<PlugAndPlayInfo>& plugAndPlayInfos) noexcept
{
    for (const auto& plugAndPlayInfo : plugAndPlayInfos)
    {
        addDevice(plugAndPlayInfo);
    }
}

void DeviceManager::onRemoveDevice(const std::vector<PlugAndPlayInfo>& plugAndPlayInfos) noexcept
{
    for (const auto& plugAndPlayInfo : plugAndPlayInfos)
    {
        removeDevice(plugAndPlayInfo);
    }
}

void DeviceManager::getDevicesConnectedAtStartup(std::vector<PlugAndPlayInfo>& plugAndPlayInfos) noexcept
{
    // TODO: Make the appropriate system calls here.  Currently this is only a test implementation.
    
    // Simulated USB device.
    PlugAndPlayInfo plugAndPlayInfo1;
    strncpy(plugAndPlayInfo1.deviceName, "PreSonus USB Microphone", strLength);
    plugAndPlayInfo1.hardwareId = 1U;
    plugAndPlayInfo1.vendorId = 1U;
    plugAndPlayInfo1.productId = 5U;
    strncpy(plugAndPlayInfo1.firmwareVersion, "1.1.1", strLength);
    plugAndPlayInfo1.serialNumber = 1U;
    plugAndPlayInfo1.numberOfInputs = 2U;
    plugAndPlayInfo1.numberOfOutputs = 10U;
    
    // Simulated Quantum device.
    PlugAndPlayInfo plugAndPlayInfo2;
    strncpy(plugAndPlayInfo2.deviceName, "PreSonus Quantum", strLength);
    plugAndPlayInfo2.hardwareId = 2U;
    plugAndPlayInfo2.vendorId = 1U;
    plugAndPlayInfo2.productId = 2U;
    strncpy(plugAndPlayInfo2.firmwareVersion, "2.1.1", strLength);
    plugAndPlayInfo2.serialNumber = 2U;
    plugAndPlayInfo2.numberOfInputs = 1U;
    plugAndPlayInfo2.numberOfOutputs = 1U;
   
    plugAndPlayInfos.push_back(plugAndPlayInfo1);
    plugAndPlayInfos.push_back(plugAndPlayInfo2);
}

void DeviceManager::runNotificationLoop() noexcept
{
    subscribeToAddEvents([this](const PlugAndPlayInfo &plugAndPlayInfo){this->addDevice(plugAndPlayInfo);});
    subscribeToRemoveEvents([this](const PlugAndPlayInfo &plugAndPlayInfo){this->removeDevice(plugAndPlayInfo);});
    
    while (m_listenForEvents)
    {
        std::this_thread::sleep_for(std::chrono::milliseconds{1});
    }
}

void DeviceManager::subscribeToAddEvents(std::function<void(const PlugAndPlayInfo& plugAndPlayInfo)>) noexcept
{
    // TODO: Implement
}

void DeviceManager::subscribeToRemoveEvents(std::function<void(const PlugAndPlayInfo& plugAndPlayInfo)>) noexcept
{
    // TODO: Implement
}

std::string DeviceManager::getDeviceList()
{
    std::lock_guard<std::mutex> lock(m_mutex);
    std::stringstream ss;
    ss << "{" << std::endl;
    ss << "  \"PreSonusDevices\": [" << std::endl;
    for (const auto &it : m_serialNumberToDevice)
    {
        ss << "  {\n";
        ss << "    " << "\"DeviceName\" : "      << "\"" << it.second->getDeviceName()      << "\"" << "," << std::endl;
        ss << "    " << "\"HardwareId\" : "      << "\"" << it.second->getHardwareId()      << "\"" << "," << std::endl;
        ss << "    " << "\"VendorId\" : "        << "\"" << it.second->getVendorId()        << "\"" << "," << std::endl;
        ss << "    " << "\"ProductId\" : "       << "\"" << it.second->getProductId()       << "\"" << "," << std::endl;
        ss << "    " << "\"FirmwareVersion\" : " << "\"" << it.second->getFirmwareVersion() << "\"" << "," << std::endl;
        ss << "    " << "\"SerialNumber\" : "    << "\"" << it.second->getSerialNumber()    << "\"" << "," << std::endl;
        ss << "    " << "\"NumberOfInputs\" : "  << "\"" << it.second->getNumberOfInputs()  << "\"" << "," << std::endl;
        ss << "    " << "\"NumberOfOutputs\" : " << "\"" << it.second->getNumberOfOutputs() << std::endl;
        ss << "  }," << std::endl;
    }
    ss << "  ]" << std::endl;
    ss << "}" << std::endl;
    
    return ss.str();
}


} // namespace
