//
// Studio USB Device
//

#include <iostream>

#include "StudioUsbDevice.hpp"

namespace PreSonus
{
bool StudioUsbDevice::controlDevice(std::uint32_t instructionId) noexcept
{
    // TODO: Implement this.
    std::cout << "Control StudioUsbDevice with InstructionId " << instructionId << std::endl;
    return true;
}

} // namespace PreSonus
