//
// Quantum Device
//

#include <iostream>

#include "QuantumDevice.hpp"

namespace PreSonus
{
bool QuantumDevice::controlDevice(std::uint32_t instructionId) noexcept
{
    // TODO: Implement this.
    std::cout << "Control QuantumDevice with InstructionId " << instructionId << std::endl;
    return true;
}

} // namespace PreSonus
