//
// Abstract base class for PreSonus devices
//
// Contains the functionality common for all devices.
//

#include "PreSonusDevice.hpp"

namespace PreSonus
{

std::string PreSonusDevice::getDeviceName() const noexcept
{
    return m_deviceName;
}

std::uint32_t PreSonusDevice::getHardwareId() const noexcept
{
    return m_hardwareId;
}

std::uint16_t PreSonusDevice::getVendorId() const noexcept
{
    return m_vendorId;
}

std::uint16_t PreSonusDevice::getProductId() const noexcept
{
    return m_productId;
}

std::string PreSonusDevice::getFirmwareVersion() const noexcept
{
    return m_firmwareVersion;
}

std::uint32_t PreSonusDevice::getSerialNumber() const noexcept
{
    return m_serialNumber;
}

std::uint16_t PreSonusDevice::getNumberOfInputs() const noexcept
{
    return m_numberOfInputs;
}

std::uint16_t PreSonusDevice::getNumberOfOutputs() const noexcept
{
    return m_numberOfOutputs;
}

void PreSonusDevice::setDeviceName(const std::string &deviceName) noexcept
{
    m_deviceName = deviceName;
}

void PreSonusDevice::setHardwareId(std::uint32_t hardwareId) noexcept
{
    m_hardwareId = hardwareId;
}

void PreSonusDevice::setVendorId(std::uint16_t vendorId) noexcept
{
    m_vendorId = vendorId;
}

void PreSonusDevice::setProductId(std::uint16_t productId) noexcept
{
    m_productId = productId;
}

void PreSonusDevice::setFirmwareVersion(const std::string &firmwareVersion) noexcept
{
    m_firmwareVersion = firmwareVersion;
}

void PreSonusDevice::setSerialNumber(std::uint32_t serialNumber) noexcept
{
    m_serialNumber = serialNumber;
}

void PreSonusDevice::setNumberOfInputs(std::uint16_t numberOfInputs) noexcept
{
    m_numberOfInputs = numberOfInputs;
}

void PreSonusDevice::setNumberOfOutputs(std::uint16_t numberOfOutputs) noexcept
{
    m_numberOfOutputs = numberOfOutputs;
}

} // namespace PreSonus
