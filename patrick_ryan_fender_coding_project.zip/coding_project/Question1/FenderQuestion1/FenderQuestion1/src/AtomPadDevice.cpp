//
// Atom Pad Device
//

#include <iostream>

#include "AtomPadDevice.hpp"

namespace PreSonus
{
bool AtomPadDevice::controlDevice(std::uint32_t instructionId) noexcept
{
    // TODO: Implement this.
    std::cout << "Control AtomPadDevice with InstructionId " << instructionId << std::endl;
    return true;
}

} // namespace PreSonus
