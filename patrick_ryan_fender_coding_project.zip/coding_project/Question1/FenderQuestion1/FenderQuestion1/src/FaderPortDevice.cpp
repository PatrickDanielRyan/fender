//
// Fader Port Device
//

#include <iostream>

#include "FaderPortDevice.hpp"

namespace PreSonus
{
bool FaderPortDevice::controlDevice(std::uint32_t instructionId) noexcept
{
    // TODO: Implement this.
    std::cout << "Control FaderPortDevice with InstructionId " << instructionId << std::endl;
    return true;
}

} // namespace PreSonus
