//
//  main.cpp
//  FenderQuestion1
//
//  Created by Patrick Ryan on 5/6/25.
//

#include <iostream>

#include "DeviceManager.hpp"

int main() {
    PreSonus::DeviceManager deviceManager;
    
    // The code below is for testing purposes and can be removed when all functionality is implemented.
    
    // Print devices at startup.
    std::cout << "----> Devices at Startup" << std::endl;
    std::cout << deviceManager.getDeviceList() << std::endl;
    
    // Simulate removal of one device.
    PlugAndPlayInfo plugAndPlayInfo;
    plugAndPlayInfo.serialNumber = 1U;
    std::vector<PlugAndPlayInfo> plugAndPlayInfos{plugAndPlayInfo};
    std::cout << "----> Remove one device" << std::endl;
    deviceManager.onRemoveDevice(plugAndPlayInfos);
    std::cout << deviceManager.getDeviceList() << std::endl;
    
    // Simulate addition of two devices.
    strncpy(plugAndPlayInfo.deviceName, "PreSonus USB Speakers", strLength);
    plugAndPlayInfo.hardwareId = 3U;
    plugAndPlayInfo.vendorId = 1U;
    plugAndPlayInfo.productId = 6U;
    strncpy(plugAndPlayInfo.firmwareVersion, "8.1.1", strLength);
    plugAndPlayInfo.serialNumber = 3U;
    plugAndPlayInfo.numberOfInputs = 1U;
    plugAndPlayInfo.numberOfOutputs = 2U;
    
    plugAndPlayInfos.clear();
    plugAndPlayInfos.push_back(plugAndPlayInfo);
    
    strncpy(plugAndPlayInfo.deviceName, "PreSonus Fader Port", strLength);
    plugAndPlayInfo.hardwareId = 8U;
    plugAndPlayInfo.vendorId = 1U;
    plugAndPlayInfo.productId = 7U;
    strncpy(plugAndPlayInfo.firmwareVersion, "2.2.1", strLength);
    plugAndPlayInfo.serialNumber = 4U;
    plugAndPlayInfo.numberOfInputs = 2U;
    plugAndPlayInfo.numberOfOutputs = 2U;
    
    plugAndPlayInfos.push_back(plugAndPlayInfo);
    
    std::cout << "----> Add two devices" << std::endl;
    deviceManager.onAddDevice(plugAndPlayInfos);
    std::cout << deviceManager.getDeviceList() << std::endl;
    
    return 0;
}
