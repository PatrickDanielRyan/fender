This program manages PreSonus devices.  Devices from other brands are currently not supported.

Device management is done using the DeviceManager class.  Currently, the only managment possibility
is to print all the devices.  This can be done via the method getDeviceList(), which returns a
JSON-formatted string of all connected devices.

Adding and Removing of devices is done through the callbacks onAddDevice() and onRemoveDevice().
These are currently called manually for test purposes but in the future should be passed as callbacks
to the appropriate kernel-level functions.

4 types of devices are supported and this reflects the class structure used.
  - PreSonusDevice (Abstract Base Class)
    - FaderPortDevice (Derived Class)
    - AtomPadDevice (Derived Class)
    - StudioUsbDevice (Derived Class)
    - QuantumDevice (Derived Class)

Controlling a device can be done via the overloaded method controlDevice(), which is not yet implemented.

Problems adding and removing a device should not cause an exception to be thrown.
Currently, all error messages are printed to standard error.

Currently, the program is tested by manually calling onAddDevice() and onRemoveDevice().
In the future, these will be called as callbacks.
