//
//  main.cpp
//  FenderQuestion2
//
//  Created by Patrick Ryan on 5/6/25.
//

#include <iostream>

#include "mixer_utility.hpp"
#include "digital_mixer.hpp"

void callback(const std::string& report)
{
    std::cout << report << std::endl;
}

int main() {
    DigitalMixer::DigitalMixer digitalMixer;
    digitalMixer.registerCallback(callback);
    
    // Test code below sets and gets a few properties.
    
    std::bitset<UniversalAddress::addressSizeInBits> address;
    
    // Set headphone volume to 4.
    address.set(UniversalAddress::bitGlobal);
    address.set(UniversalAddress::bitVolume);
    digitalMixer.setProperty(address, 4);
    
    // Set channel channel gain to 1 for channels 4 and 5.
    address.reset();
    address.set(UniversalAddress::bitChannel0 + 4);
    address.set(UniversalAddress::bitChannel0 + 5);
    address.set(UniversalAddress::bitGain);
    digitalMixer.setProperty(address, 2);
    
    // Get headphone volume.
    auto globalVolume = digitalMixer.getGlobalProperty(UniversalAddress::bitVolume);
    std::cout << "GetGlobalVolume: "
              << "Success=" << globalVolume.first << " "
              << "Value=" << static_cast<int>(globalVolume.second)
              << std::endl;
    
    // Get Volume for Channel 4.
    auto channelVolume = digitalMixer.getChannelProperty(4U, UniversalAddress::bitVolume);
    std::cout << "GetChannelVolume: "
              << "Success=" << channelVolume.first << " "
              << "Value=" << static_cast<int>(channelVolume.second)
              << std::endl;
    
    // Get Gain for Channel 4.
    auto channelGain = digitalMixer.getChannelProperty(4U, UniversalAddress::bitGain);
    std::cout << "GetChannelGain: "
              << "Success=" << channelGain.first << " "
              << "Value=" << static_cast<int>(channelGain.second)
              << std::endl;
    
    
    return 0;
}
