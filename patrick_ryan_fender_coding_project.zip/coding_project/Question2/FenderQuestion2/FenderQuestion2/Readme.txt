This program simulates a very basic digital mixer.

The mixer has the following global properties
  - Headphone Volume (Range from 0 to 10)
  - Channels (16 Channels are supported)
  
Each channel has the following properties
  - Mute (on or off)
  - Volume (Range from 0 to 10)
  - Gain (Range from 0 to 10)
  - Pan (Range from -10 to 10)

The properties described above can be configured via the setProperty() method in the DigitalMixer class.
It is not possible to set a property above or below its defined minimum or maximum value.

A universal addressing scheme is used to set the properties.  It is as follows.
  - Bits 0 - 15: Properties
    - Bit 0: Volume (channel volume or headphone volume)
    - Bit 1: Channel mute
    - Bit 2: Channel gain
    - Bit 3: Channel pan
 - Bits 16 - 32: Channel select (channel 0 corresponds to bit 16 and channel 16 corresponds to bit 32)
 - Bit 63: Global (set to 1) or Channel (set to 0)

A single property can be set for multiple channels in one function call but it is not possible to set
multiple properties for a single channel (or multiple channels) in a single function call.

A callback function that takes a string as a parameter can be registered to provide a notification when a property is set.

If there is an error while trying to get or set a property, an error message is printed to standard error
and the property is not set or retrieved.
