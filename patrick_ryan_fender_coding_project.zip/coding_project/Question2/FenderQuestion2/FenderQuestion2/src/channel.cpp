//
// A single channel on the digital mixer.
//

#include "mixer_utility.hpp"
#include "channel.hpp"

namespace DigitalMixer
{

void Channel::setMute(std::int8_t mute) noexcept
{
    m_mute = static_cast<bool>(mute);
}

void Channel::setVolume(std::int8_t volume) noexcept
{
    m_volume = clamp(volume, k_minVolume, k_maxVolume);
}

void Channel::setGain(std::int8_t gain) noexcept
{
   m_gain = clamp(gain, k_minGain, k_maxGain);
}

void Channel::setPan(std::int8_t pan) noexcept
{
   m_pan = clamp(pan, k_minPan, k_maxPan);
}

std::int8_t Channel::getMute() const noexcept
{
    return m_mute;
}

std::int8_t Channel::getVolume() const noexcept
{
    return m_volume;
}

std::int8_t Channel::getGain() const noexcept
{
    return m_gain;
}

std::int8_t Channel::getPan() const noexcept
{
    return m_pan;
}

} // namespace
