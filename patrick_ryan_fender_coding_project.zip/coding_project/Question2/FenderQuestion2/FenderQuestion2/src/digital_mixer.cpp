//
// Global level of a 16-channel digital mixer.
//

#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>

#include "digital_mixer.hpp"
#include "mixer_utility.hpp"

namespace DigitalMixer
{


void DigitalMixer::setProperty(const Address &address, std::int8_t value) noexcept
{
    try
    {
        if (UniversalAddress::isGlobal(address))
        {
            if (UniversalAddress::isProperty(address, UniversalAddress::bitVolume))
            {
                setHeadphoneVolume(value);
            }
        }
        else
        {
            for (uint8_t i = 0U; i < numberOfChannels; ++i)
            {
                if (UniversalAddress::isChannel(address, i))
                {
                    if (UniversalAddress::isProperty(address, UniversalAddress::bitVolume))
                    {
                        m_channels.at(i).setVolume(value);
                    }
                    else if (UniversalAddress::isProperty(address, UniversalAddress::bitMute))
                    {
                        m_channels.at(i).setMute(value);
                    }
                    else if (UniversalAddress::isProperty(address, UniversalAddress::bitGain))
                    {
                        m_channels.at(i).setGain(value);
                    }
                    else if (UniversalAddress::isProperty(address, UniversalAddress::bitPan))
                    {
                        m_channels.at(i).setPan(value);
                    }
                    else
                    {
                        std::cerr << "Attempt to set an invalid property" << std::endl;
                        return;
                    }
                }
            }
        }
    }
    catch (const std::exception &e)
    {
        std::cerr << "Could not set property: " << e.what() << std::endl;
        return;
    }
    
    // Inform callback that a property was sucessfully set.
    std::stringstream ss;
    ss << "SetProperty: Address=0x" << std::hex << std::setw(16) << std::setfill('0') << address.to_ulong() << std::dec;
    ss << " value=" << static_cast<int>(value);
    m_callback(ss.str());
}

std::pair<bool, std::int8_t> DigitalMixer::getGlobalProperty(std::size_t propertyBit) noexcept
{
    if (propertyBit == UniversalAddress::bitVolume)
    {
        return std::pair<bool, std::int8_t>(true, getHeadphoneVolume());
    }
  
    std::cerr << "Illegal property bit: " << propertyBit << std::endl;
    return std::pair<bool, std::int8_t>(false, 0);
}

std::pair<bool, std::int8_t> DigitalMixer::getChannelProperty(std::size_t channel, std::size_t propertyBit) noexcept
{
    try
    {
        const auto& selectedChannel = m_channels.at(channel);
        
        if (propertyBit == UniversalAddress::bitVolume)
        {
            return std::pair<bool, std::int8_t>(true, selectedChannel.getVolume());
        }
        if (propertyBit == UniversalAddress::bitMute)
        {
            return std::pair<bool, std::int8_t>(true, selectedChannel.getMute());
        }
        if (propertyBit == UniversalAddress::bitGain)
        {
            return std::pair<bool, std::int8_t>(true, selectedChannel.getGain());
        }
        if (propertyBit == UniversalAddress::bitPan)
        {
            return std::pair<bool, std::int8_t>(true, selectedChannel.getPan());
        }
        
        std::cerr << "Illegal property bit: " << propertyBit << std::endl;
        return std::pair<bool, std::int8_t>(false, 0);
    }
    catch (const std::exception &e)
    {
        std::cerr << "Error getting channel property for cahnnel " << channel << ": " << e.what() << std::endl;
        return std::pair<bool, std::int8_t>(false, 0);
    }
}

void DigitalMixer::setHeadphoneVolume(std::int8_t headphoneVolume) noexcept
{
    m_headphoneVolume = clamp(headphoneVolume, k_minHeadphoneVolume, k_maxHeadphoneVolume);
}

std::int8_t DigitalMixer::getHeadphoneVolume() noexcept
{
    return m_headphoneVolume;
}

void DigitalMixer::registerCallback(std::function<void(const std::string&)> callbackFunction) noexcept
{
    m_callback = callbackFunction;
}

} // namespace
