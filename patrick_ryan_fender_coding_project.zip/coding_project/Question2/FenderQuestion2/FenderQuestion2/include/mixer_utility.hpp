//
// Utilities to support digital mixer
//

#ifndef MIXER_UTILITY_HPP
#define MIXER_UTILITY_HPP

#include <bitset>
#include <functional>

namespace DigitalMixer
{

template<class T>
constexpr const T& clamp(const T& v, const T& lo, const T& hi)
{
    return clamp(v, lo, hi, [](const T& lhs, const T& rhs){ return lhs < rhs; });
}

template<class T, class Compare>
constexpr const T& clamp(const T& v, const T& lo, const T& hi, Compare comp)
{
    return comp(v, lo) ? lo : comp(hi, v) ? hi : v;
}

} // namespace

namespace UniversalAddress
{
// The universal address is used to configure all properties at both the global and channel level.
// Bits are numbered from 0 (lowest bit) to 63 (highest bit).
//
// - Bits 0 - 15: Properties
//   - Bit 0: Volume (channel or headphone)
//   - Bit 1: Channel mute
//   - Bit 2: Channel gain
//   - Bit 3: Channel pan
// - Bits 16 - 32: Channel select (channel 0 corresponds to bit 16 and channel 16 corresponds to bit 32)
// - Bit 63: Global (set to 1) or Channel (set to 0)

constexpr uint8_t addressSizeInBits = 64;

constexpr size_t bitVolume = 0U;
constexpr size_t bitMute = 1U;
constexpr size_t bitGain = 2U;
constexpr size_t bitPan = 3U;
constexpr size_t bitChannel0 = 16U;
constexpr size_t bitGlobal = 63U;

inline bool isGlobal(const std::bitset<addressSizeInBits> &bits)
{
    return bits.test(bitGlobal);
}

inline bool isChannel(const std::bitset<addressSizeInBits> &bits, size_t channelNumber)
{
    return bits.test(bitChannel0 + channelNumber);
}

inline bool isProperty(const std::bitset<addressSizeInBits> &bits, size_t property)
{
    return bits.test(property);
}

} // namespace



#endif

