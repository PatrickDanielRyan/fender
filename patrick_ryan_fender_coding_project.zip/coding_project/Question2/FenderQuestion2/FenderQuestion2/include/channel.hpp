//
// A single channel on the digital mixer.
//

#include <cstdint>

namespace DigitalMixer
{

constexpr std::int8_t k_minVolume = 0;
constexpr std::int8_t k_maxVolume = 10;
constexpr std::int8_t k_minGain = 0;
constexpr std::int8_t k_maxGain = 10;
constexpr std::int8_t k_minPan = -10;
constexpr std::int8_t k_maxPan = -10;

class Channel
{
public:
    Channel() = default;
    Channel(const Channel&) = delete;
    Channel(Channel&&) = delete;
    Channel operator=(const Channel&) = delete;
    Channel operator=(Channel&&) = delete;
    
    void setMute(std::int8_t mute) noexcept;
    void setVolume(std::int8_t volume) noexcept;
    void setGain(std::int8_t gain) noexcept;
    void setPan(std::int8_t pan) noexcept;
    
    std::int8_t getMute() const noexcept;
    std::int8_t getVolume() const noexcept;
    std::int8_t getGain() const noexcept;
    std::int8_t getPan() const noexcept;

private:
    std::int8_t m_mute = 0;       // Zero if channel is not muted.
    std::int8_t m_volume = 0;     // Channel volume.
    std::int8_t m_gain = 0;       // Channel gain.
    std::int8_t m_pan = 0;        // Channel pan.
};

} // namespace
