//
// Global level of a 16-channel digital mixer
//

#include <array>

#include "mixer_utility.hpp"
#include "channel.hpp"

namespace DigitalMixer
{

constexpr uint8_t numberOfChannels = 16U;

constexpr std::int8_t k_minHeadphoneVolume = 0;
constexpr std::int8_t k_maxHeadphoneVolume = 10;

using Address = std::bitset<UniversalAddress::addressSizeInBits>;

class DigitalMixer
{
public:
    DigitalMixer() = default;
    DigitalMixer(const DigitalMixer&) = delete;
    DigitalMixer(DigitalMixer&&) = delete;
    DigitalMixer operator=(const DigitalMixer&) = delete;
    DigitalMixer operator=(DigitalMixer&&) = delete;
    
    // Set global and channel properties.
    // It is possible to set a single property for multiple channels at once.
    void setProperty(const Address &address, std::int8_t value) noexcept;
    
    // The first parameter in the getter return value indicates success or failure.  The parameter second is the actual value.
    std::pair<bool, std::int8_t> getGlobalProperty(std::size_t propertyBit) noexcept;
    std::pair<bool, std::int8_t> getChannelProperty(std::size_t channel, std::size_t propertyBit) noexcept;
    
    // Callback called when a property is set.
    void registerCallback(std::function<void(const std::string&)>) noexcept;
    
private:
    void setHeadphoneVolume(std::int8_t headphoneVolume) noexcept; // Sets global headphone volume.
    std::int8_t getHeadphoneVolume() noexcept;                     // Gets global headphone volume.
    
    std::function<void(const std::string&)> m_callback = [](const std::string&){}; // Function to report property updates.
    std::int8_t m_headphoneVolume = 0U;                                            // Global headphone volume.
    std::array<Channel, numberOfChannels> m_channels;                              // Array of Channels.
};

}
